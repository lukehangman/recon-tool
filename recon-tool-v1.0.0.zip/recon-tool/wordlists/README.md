# Wordlists

This directory contains wordlists used by the Recon Automation Tool for various enumeration tasks.

## 📋 Available Wordlists

### subdomains.txt

**Purpose:** Subdomain enumeration  
**Entries:** 150+  
**Type:** Common subdomain names

**Description:**  
A carefully curated list of common subdomain names used by organizations worldwide. This wordlist includes:

- Standard web services (www, mail, ftp)
- Email services (smtp, pop, webmail, autodiscover)
- Name servers (ns1-ns10)
- Development environments (dev, staging, test, beta, alpha)
- API endpoints (api, rest, graphql)
- Content delivery (cdn, static, assets, media)
- Administrative panels (admin, cpanel, webmaster)
- Security services (vpn, ssl, secure)
- Monitoring tools (monitor, status, health)
- DevOps tools (jenkins, gitlab, docker, k8s)
- Databases (mysql, postgres, mongodb, redis)
- Messaging systems (kafka, rabbitmq)
- Cloud services (aws, azure, gcp)

**Usage:**
```bash
# Use default wordlist
python3 recon.py -u example.com

# Use custom wordlist
python3 recon.py -u example.com -w /path/to/custom_wordlist.txt
```

## 🔧 Creating Custom Wordlists

### Best Practices

1. **One subdomain per line**
   ```
   www
   mail
   api
   ```

2. **No protocols or dots**
   ```
   ✅ Correct: www
   ❌ Wrong: www.
   ❌ Wrong: https://www
   ```

3. **Lowercase preferred**
   ```
   ✅ Correct: admin
   ⚠️ Acceptable: Admin (will work but lowercase is standard)
   ```

4. **No duplicates**
   - Remove duplicate entries
   - Sort alphabetically for easier maintenance

5. **No comments or empty lines**
   - Keep the file clean
   - Use separate documentation files

### Custom Wordlist Example

```bash
# Create a targeted wordlist for a specific industry
cat > custom_financial.txt << EOF
banking
payments
transactions
accounts
loans
credit
debit
invest
trading
portfolio
wealth
insurance
claims
benefits
EOF

# Use it
python3 recon.py -u financialcompany.com -w custom_financial.txt
```

## 📊 Wordlist Statistics

### Default Subdomain Wordlist (subdomains.txt)

| Category              | Count |
|-----------------------|-------|
| Web Services          | 15    |
| Email/Communication   | 10    |
| Name Servers          | 10    |
| Development           | 12    |
| APIs                  | 8     |
| CDN/Static            | 8     |
| Admin/Management      | 10    |
| Security              | 8     |
| DevOps/CI-CD          | 15    |
| Databases             | 10    |
| Monitoring            | 8     |
| Cloud Services        | 12    |
| Other                 | 24    |
| **Total**             | **150+** |

## 🎯 Wordlist Sources

Our default wordlist is compiled from:

1. **Common Patterns**: Industry-standard subdomain naming conventions
2. **OWASP**: Open Web Application Security Project recommendations
3. **Bug Bounty Programs**: Frequently discovered subdomains
4. **Public Research**: Academic papers and security blogs
5. **Penetration Testing Experience**: Real-world testing scenarios

## 📚 Additional Wordlist Resources

For more comprehensive subdomain enumeration, consider these external resources:

### Small Wordlists (Fast)
- **subdomains-top1million-5000.txt** - Top 5000 subdomains
- **fierce-hostlist.txt** - ~2000 entries

### Medium Wordlists (Balanced)
- **subdomains-top1million-20000.txt** - Top 20000 subdomains
- **namelist.txt** - ~150,000 entries

### Large Wordlists (Comprehensive)
- **all.txt** - 1,000,000+ entries
- **subdomains-top1million-110000.txt** - Top 110,000 subdomains

**Note:** Larger wordlists take significantly longer to process.

### Where to Find More Wordlists

```bash
# SecLists (GitHub)
git clone https://github.com/danielmiessler/SecLists.git
cd SecLists/Discovery/DNS/

# All.txt (Comprehensive)
wget https://gist.githubusercontent.com/jhaddix/86a06c5dc309d08580a018c66354a056/raw/96f4e51d96b2203f19f6381c8c545b278eaa0837/all.txt
```

## ⚡ Performance Tips

### Wordlist Size vs. Scan Time

| Wordlist Size | Threads | Approx. Time |
|---------------|---------|--------------|
| 150 entries   | 10      | 30-60 sec    |
| 1,000 entries | 20      | 2-3 min      |
| 5,000 entries | 50      | 5-10 min     |
| 20,000 entries| 100     | 20-30 min    |
| 100,000+ entries | 100  | 1-2 hours    |

### Optimization Strategies

1. **Start Small**: Use our default wordlist first
2. **Increase Threads**: Use `-t 50` or `-t 100` for faster scanning
3. **Filter Results**: Focus on specific subdomain types
4. **Split Large Lists**: Break into smaller, targeted lists

```bash
# Fast scan with default list
python3 recon.py -u example.com -t 20

# Comprehensive scan with large list
python3 recon.py -u example.com -w large_wordlist.txt -t 100
```

## 🔍 Wordlist Maintenance

### Updating the Wordlist

```bash
# Add new entries
echo "newsubdomain" >> wordlists/subdomains.txt

# Remove duplicates and sort
sort -u wordlists/subdomains.txt -o wordlists/subdomains.txt

# Count entries
wc -l wordlists/subdomains.txt
```

### Quality Control

Periodically review and update the wordlist:

1. **Add new patterns** based on discoveries
2. **Remove obsolete entries** (deprecated services)
3. **Sort alphabetically** for easier maintenance
4. **Test effectiveness** on various targets

## 🛡️ Security Considerations

### Wordlist Privacy

- **Don't include** client-specific subdomains
- **Avoid** personally identifiable information
- **Keep custom lists** private if they contain sensitive patterns
- **Review before sharing** to prevent information disclosure

### Ethical Usage

- Only use on authorized targets
- Be aware of rate limiting
- Consider target resources
- Respect robots.txt and security.txt

## 📝 Contributing Wordlists

Want to contribute a wordlist? Please ensure:

1. **No client-specific data**
2. **Properly formatted** (one per line, lowercase)
3. **No duplicates**
4. **Tested on multiple targets**
5. **Documented** (purpose, size, source)

See [CONTRIBUTING.md](../CONTRIBUTING.md) for more details.

## 📖 References

- [OWASP Testing Guide](https://owasp.org/www-project-web-security-testing-guide/)
- [SecLists Repository](https://github.com/danielmiessler/SecLists)
- [DNS Enumeration Techniques](https://en.wikipedia.org/wiki/DNS_enumeration)

---

**Last Updated:** January 15, 2024  
**Wordlist Version:** 1.0.0  
**Maintained By:** Recon Tool Contributors

For questions or suggestions, please open an issue on GitHub.
